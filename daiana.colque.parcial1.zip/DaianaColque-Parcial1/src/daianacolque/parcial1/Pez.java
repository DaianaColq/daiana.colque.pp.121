
package daianacolque.parcial1;

public class Pez extends Especie implements Alimentable {
    private double longitudMaxima;

    public Pez(String nombre, String tanque, TipoAgua tipo, double longitudMaxima) {
        super(nombre, tanque, tipo);
        this.longitudMaxima = longitudMaxima;
    }

    public double getLongitudMaxima() {
        return longitudMaxima;
    }

    @Override
    public void alimentar() {
        System.out.println(getNombreComun() + " ha sido alimentado con alimento para peces.");
    }

    @Override
    public String toString() {
        return super.toString() + ", Longitud máxima: " + longitudMaxima + " cm";
    }
}
