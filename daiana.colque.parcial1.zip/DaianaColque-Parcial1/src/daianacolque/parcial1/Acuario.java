package daianacolque.parcial1;

import java.util.*;

public class Acuario {
    private final List<Especie> especies = new ArrayList<>();

    public void agregarEspecie(Especie especie) throws EspecieDuplicadaException {
        for (Especie e : especies) {
            if (e.getNombreComun().equalsIgnoreCase(especie.getNombreComun()) &&
                e.getTanque().equalsIgnoreCase(especie.getTanque())) {
                throw new EspecieDuplicadaException("Ya existe una especie con ese nombre en el mismo tanque.");
            }
        }
        especies.add(especie);
        System.out.println("Especie agregada: " + especie.getNombreComun());
    }

    public void mostrarEspecies() {
        if (especies.isEmpty()) {
            System.out.println("No hay especies registradas.");
            return;
        }
        for (Especie e : especies) {
            System.out.println(e);
        }
    }

    public void alimentarEspecies() {
        for (Especie e : especies) {
            if (e instanceof Alimentable) {
                ((Alimentable) e).alimentar();
            } else {
                System.out.println(e.getNombreComun() + " no se alimenta.");
            }
        }
    }

    public void filtrarPorTipoAgua(TipoAgua tipo) {
        System.out.println("Especies en " + tipo + ":");
        for (Especie e : especies) {
            if (e.getTipoAgua() == tipo) {
                System.out.println(e);
            }
        }
    }

    public List<Especie> getEspecies() {
        return new ArrayList<>(especies);
    }
}
