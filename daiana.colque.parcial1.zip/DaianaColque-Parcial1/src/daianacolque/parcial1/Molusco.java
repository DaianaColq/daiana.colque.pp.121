package daianacolque.parcial1;

public class Molusco extends Especie implements Alimentable {
    private String tipoConcha;

    public Molusco(String nombre, String tanque, TipoAgua tipo, String tipoConcha) {
        super(nombre, tanque, tipo);
        this.tipoConcha = tipoConcha;
    }

    public String getTipoConcha() {
        return tipoConcha;
    }

    @Override
    public void alimentar() {
        System.out.println(getNombreComun() + " ha sido alimentado con plancton.");
    }

    @Override
    public String toString() {
        return super.toString() + ", Tipo de concha: " + tipoConcha;
    }
}
