package daianacolque.parcial1;

public class EspecieDuplicadaException extends Exception {
    public EspecieDuplicadaException(String mensaje) {
        super(mensaje);
    }
}
