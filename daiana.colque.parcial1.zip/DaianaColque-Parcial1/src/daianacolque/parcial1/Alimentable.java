package daianacolque.parcial1;

public interface Alimentable {
    void alimentar();
}


