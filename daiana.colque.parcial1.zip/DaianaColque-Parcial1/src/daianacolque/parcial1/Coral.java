package daianacolque.parcial1;

public class Coral extends Especie {
    private double profundidadIdeal;

    public Coral(String nombre, String tanque, TipoAgua tipo, double profundidadIdeal) {
        super(nombre, tanque, tipo);
        this.profundidadIdeal = profundidadIdeal;
    }

    public double getProfundidadIdeal() {
        return profundidadIdeal;
    }

    @Override
    public String toString() {
        return super.toString() + ", Profundidad ideal: " + profundidadIdeal + " m";
    }
}
