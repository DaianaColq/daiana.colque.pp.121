package daianacolque.parcial1;

public abstract class Especie {
    private String nombreComun;
    private String tanque;
    private TipoAgua tipoAgua;

    public Especie(String nombreComun, String tanque, TipoAgua tipoAgua) {
        this.nombreComun = nombreComun;
        this.tanque = tanque;
        this.tipoAgua = tipoAgua;
    }

    public String getNombreComun() {
        return nombreComun;
    }

    public String getTanque() {
        return tanque;
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombreComun + ", Tanque: " + tanque + ", Tipo de agua: " + tipoAgua;
    }
}

